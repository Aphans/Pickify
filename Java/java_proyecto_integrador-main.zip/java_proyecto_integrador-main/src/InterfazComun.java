
public interface InterfazComun {
	public void crearInterfaz();
	public void procesar();
	public void refrescarIdioma();
}
