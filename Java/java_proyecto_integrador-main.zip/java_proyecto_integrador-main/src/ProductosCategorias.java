
public class ProductosCategorias {
	final public static short CAT_ROPA = 1000;
	final public static short CAT_COMIDA = 2000;
	final public static short CAT_LIBROS = 3000;
}
